#ifndef HTTP_SERVER_H
#define HTTP_SERVER_H

#include <Arduino.h>
#include <WiFi.h>
#include "config.h"
#include "authentication.h"
#include "led_control.h"
#include "html_pages.h"

// HTTP server instance
WiFiServer httpServer(HTTP_PORT);

// Handle HTTP requests
void handleHTTPRequests() {
  WiFiClient client = httpServer.available();
  
  if (!client) {
    return;
  }
  
  Serial.println("\n========================================");
  Serial.println("New HTTP client connected");
  Serial.println("========================================");
  
  // Wait for data
  unsigned long timeout = millis();
  while(!client.available() && millis() - timeout < 1000) {
    delay(1);
  }
  
  if(!client.available()) {
    Serial.println("Client timeout - no data received");
    client.stop();
    return;
  }
  
  // Read request
  String request = "";
  while(client.connected() && client.available()) {
    char c = client.read();
    request += c;
    if(request.endsWith("\r\n\r\n")) break;  // End of headers
  }
  
  // Parse request line
  String requestLine = request.substring(0, request.indexOf('\n'));
  Serial.print("Request Line: ");
  Serial.println(requestLine);
  
  // Handle login POST request
  if(requestLine.indexOf("POST /login") >= 0) {
    Serial.println(">>> DETECTED: POST /login <<<");
    
    // Extract username and password from POST body
    String body = "";
    
    // Read the POST body
    delay(50);  // Give client time to send body
    while(client.available()) {
      body += (char)client.read();
    }
    
    String username = "";
    String password = "";
    
    // Parse form data (username=XXX&password=YYY)
    int userPos = body.indexOf("username=");
    int passPos = body.indexOf("&password=");
    
    if(userPos >= 0 && passPos >= 0) {
      username = body.substring(userPos + 9, passPos);
      password = body.substring(passPos + 10);
      username.trim();
      password.trim();
    }
    
    Serial.print("Username: '");
    Serial.print(username);
    Serial.println("'");
    
    // Authenticate
    int role = authenticateUser(username, password);
    
    if(role > 0) {
      // Success - create session
      session.username = username;
      session.role = role;
      session.token = generateToken();
      session.active = true;
      
      Serial.println("✓✓✓ LOGIN SUCCESS ✓✓✓");
      
      // Send redirect to main page with cookie
      client.println("HTTP/1.1 302 Found");
      client.println("Set-Cookie: session=" + session.token + "; Path=/");
      client.println("Location: /");
      client.println("Connection: close");
      client.println();
    } else {
      // Failed - redirect back to login
      Serial.println("✗✗✗ LOGIN FAILED ✗✗✗");
      client.println("HTTP/1.1 302 Found");
      client.println("Location: /?error=1");
      client.println("Connection: close");
      client.println();
    }
  }
  // Handle logout
  else if(requestLine.indexOf("GET /logout") >= 0) {
    Serial.println(">>> DETECTED: GET /logout <<<");
    session.active = false;
    session.username = "";
    session.role = 0;
    session.token = "";
    
    client.println("HTTP/1.1 302 Found");
    client.println("Location: /");
    client.println("Connection: close");
    client.println();
  }
  // Handle LED control (admin only)
  else if(requestLine.indexOf("GET /led?") >= 0) {
    Serial.println(">>> DETECTED: GET /led <<<");
    
    if(session.role == 2) {
      // Parse LED control parameters
      int colorStart = request.indexOf("color=") + 6;
      int stateStart = request.indexOf("state=") + 6;
      
      String color = request.substring(colorStart, request.indexOf('&', colorStart));
      String state = request.substring(stateStart, request.indexOf(' ', stateStart));
      
      Serial.print("LED Control: color=");
      Serial.print(color);
      Serial.print(", state=");
      Serial.println(state);
      
      setLED(color, state == "on");
    } else {
      Serial.println("ACCESS DENIED - not admin");
    }
    
    // Send redirect back to main page
    client.println("HTTP/1.1 302 Found");
    client.println("Location: /");
    client.println("Connection: close");
    client.println();
  }
  // Handle main page
  else {
    Serial.println(">>> DETECTED: Main page request <<<");
    Serial.print("Session active: ");
    Serial.println(session.active);
    
    if(session.active) {
      Serial.println("Sending MAIN PAGE");
      sendMainPage(client);
    } else {
      Serial.println("Sending LOGIN PAGE");
      sendLoginPage(client);
    }
  }
  
  client.stop();
  Serial.println("Client disconnected\n");
}

// Initialize HTTP server
void initHTTPServer() {
  httpServer.begin();
  Serial.println("✓ HTTP Server started on port " + String(HTTP_PORT));
}

#endif