#ifndef WEBSOCKET_HANDLER_H
#define WEBSOCKET_HANDLER_H

#include <Arduino.h>
#include <WebSocketsServer.h>
#include "config.h"
#include "led_control.h"
#include "history_log.h"

// WebSocket server instance
WebSocketsServer webSocket(WEBSOCKET_PORT);

// Broadcast LED state via WebSocket
void broadcastLEDState() {
  String jsonData = getLEDStateJSON();
  webSocket.broadcastTXT(jsonData);
}

// Broadcast history via WebSocket
void broadcastHistory() {
  String output = getHistoryJSON();
  webSocket.broadcastTXT(output);
}

// WebSocket event handler
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  switch(type) {
    case WStype_DISCONNECTED:
      Serial.print("[");
      Serial.print(num);
      Serial.println("] WebSocket Disconnected");
      break;
      
    case WStype_CONNECTED:
      {
        Serial.print("[");
        Serial.print(num);
        Serial.println("] WebSocket Connected");
        
        // Send current LED state to new client
        String jsonData = getLEDStateJSON();
        webSocket.sendTXT(num, jsonData);
      }
      break;
      
    case WStype_TEXT:
      Serial.print("[");
      Serial.print(num);
      Serial.print("] WebSocket message: ");
      Serial.println((char*)payload);
      // Future: handle WebSocket commands if needed
      break;
  }
}

// Initialize WebSocket server
void initWebSocket() {
  webSocket.begin();
  webSocket.onEvent(webSocketEvent);
  Serial.println("✓ WebSocket Server started on port " + String(WEBSOCKET_PORT));
}

#endif