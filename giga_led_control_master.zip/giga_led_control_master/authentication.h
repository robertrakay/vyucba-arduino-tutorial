#ifndef AUTHENTICATION_H
#define AUTHENTICATION_H

#include <Arduino.h>

// User credentials and roles
struct User {
  String username;
  String password;
  uint8_t role;  // 1=user, 2=admin
};

User users[] = {
  {"admin", "admin", 2},
  {"user", "user", 1}
};

// Active session
struct Session {
  String username;
  uint8_t role;
  String token;
  bool active;
} session = {"", 0, "", false};

// Generate simple session token
String generateToken() {
  String token = "";
  for(int i = 0; i < 16; i++) {
    token += String(random(0, 16), HEX);
  }
  return token;
}

// Check user credentials
int authenticateUser(String username, String password) {
  for(int i = 0; i < 2; i++) {
    if(users[i].username == username && users[i].password == password) {
      return users[i].role;  // Return role: 1=user, 2=admin
    }
  }
  return 0;  // Authentication failed
}

#endif