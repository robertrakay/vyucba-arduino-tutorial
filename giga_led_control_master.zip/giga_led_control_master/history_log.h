#ifndef HISTORY_LOG_H
#define HISTORY_LOG_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include "config.h"

// History log (circular buffer for last 10 changes)
struct LogEntry {
  String timestamp;
  String user;
  String action;
};

LogEntry history[HISTORY_SIZE];
int historyIndex = 0;
int historyCount = 0;

// Forward declaration
void broadcastHistory();

// Add entry to history log
void addToHistory(String user, String action) {
  history[historyIndex].timestamp = String(millis() / 1000) + "s";
  history[historyIndex].user = user;
  history[historyIndex].action = action;
  
  historyIndex = (historyIndex + 1) % HISTORY_SIZE;  // Circular buffer
  if(historyCount < HISTORY_SIZE) historyCount++;
  
  // Broadcast history update to all WebSocket clients
  broadcastHistory();
}

// Get history as JSON
String getHistoryJSON() {
  StaticJsonDocument<1024> doc;
  JsonArray arr = doc.to<JsonArray>();
  
  // Send history in reverse order (newest first)
  for(int i = historyCount - 1; i >= 0; i--) {
    int idx = (historyIndex - historyCount + i + HISTORY_SIZE) % HISTORY_SIZE;
    JsonObject entry = arr.createNestedObject();
    entry["time"] = history[idx].timestamp;
    entry["user"] = history[idx].user;
    entry["action"] = history[idx].action;
  }
  
  String output;
  serializeJson(doc, output);
  return output;
}

#endif