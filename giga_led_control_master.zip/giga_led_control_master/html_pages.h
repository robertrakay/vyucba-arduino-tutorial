#ifndef HTML_PAGES_H
#define HTML_PAGES_H

#include <Arduino.h>
#include <WiFi.h>
#include "authentication.h"
#include "led_control.h"
#include "history_log.h"
#include "config.h"

void sendLoginPage(WiFiClient &client) {
  client.println("HTTP/1.1 200 OK");
  client.println("Content-Type: text/html");
  client.println("Connection: close");
  client.println();
  
  client.print(F("<!DOCTYPE html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>"));
  client.print(F("<title>Arduino GIGA - Login</title><style>"));
  client.print(F("body{font-family:Arial,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);display:flex;justify-content:center;align-items:center;height:100vh;margin:0}"));
  client.print(F(".login-box{background:white;padding:40px;border-radius:10px;box-shadow:0 10px 25px rgba(0,0,0,0.3);width:300px}"));
  client.print(F("h1{text-align:center;color:#333;margin-bottom:30px}"));
  client.print(F("input{width:100%;padding:12px;margin:10px 0;border:1px solid #ddd;border-radius:5px;box-sizing:border-box}"));
  client.print(F("button{width:100%;padding:12px;background:#667eea;color:white;border:none;border-radius:5px;cursor:pointer;font-size:16px}"));
  client.print(F("button:hover{background:#5568d3}.error{color:red;text-align:center;margin-top:10px}"));
  client.print(F("</style></head><body><div class='login-box'><h1>🔐 Arduino GIGA</h1>"));
  client.print(F("<h2 style='text-align:center;color:#666;margin-top:-10px;font-size:16px'>LED Control System</h2>"));
  client.print(F("<form method='POST' action='/login'>"));
  client.print(F("<input type='text' name='username' placeholder='Username' required>"));
  client.print(F("<input type='password' name='password' placeholder='Password' required>"));
  client.print(F("<button type='submit'>Login</button></form>"));
  client.print(F("<p class='error' id='error'></p>"));
  client.print(F("<p style='text-align:center;margin-top:20px;color:#999;font-size:12px'>admin/admin or user/user</p></div>"));
  client.print(F("<script>if(window.location.search.includes('error=1')){document.getElementById('error').textContent='Invalid credentials!';}</script>"));
  client.print(F("</body></html>"));
}

void sendMainPage(WiFiClient &client) {
  client.println("HTTP/1.1 200 OK");
  client.println("Content-Type: text/html");
  client.println("Connection: close");
  client.println();
  
  // Header
  client.print(F("<!DOCTYPE html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1.0'>"));
  client.print(F("<title>Arduino GIGA - LED Control</title><style>"));
  client.print(F("*{margin:0;padding:0;box-sizing:border-box}"));
  client.print(F("body{font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;background:#f0f2f5}"));
  client.print(F(".header{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:white;padding:15px;box-shadow:0 2px 10px rgba(0,0,0,0.1)}"));
  client.print(F(".header-content{max-width:1000px;margin:0 auto;display:flex;justify-content:space-between;align-items:center}"));
  client.print(F("h1{font-size:20px}.user-info{display:flex;align-items:center;gap:10px;font-size:14px}"));
  client.print(F(".logout-btn{background:rgba(255,255,255,0.2);color:white;border:1px solid white;padding:6px 12px;border-radius:5px;cursor:pointer;text-decoration:none;font-size:13px}"));
  client.print(F(".logout-btn:hover{background:rgba(255,255,255,0.3)}"));
  client.print(F(".container{max-width:1000px;margin:20px auto;padding:0 15px}"));
  client.print(F(".card{background:white;border-radius:8px;padding:18px;margin-bottom:15px;box-shadow:0 2px 10px rgba(0,0,0,0.05)}"));
  client.print(F("h2{color:#333;margin-bottom:15px;border-bottom:2px solid #667eea;padding-bottom:8px;font-size:18px}"));
  client.print(F(".led-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin-top:15px}"));
  client.print(F(".led-control{border:2px solid #e0e0e0;border-radius:8px;padding:15px;text-align:center;transition:all 0.3s}"));
  client.print(F(".led-control:hover{box-shadow:0 5px 15px rgba(0,0,0,0.1)}.led-control h3{font-size:16px;margin-bottom:8px}"));
  client.print(F(".led-indicator{width:60px;height:60px;border-radius:50%;margin:0 auto 12px;border:3px solid #ddd;transition:all 0.3s}"));
  client.print(F(".led-indicator.on{box-shadow:0 0 20px}"));
  client.print(F(".red.on{background:#ff4444;border-color:#ff4444;box-shadow:0 0 30px #ff4444}"));
  client.print(F(".green.on{background:#44ff44;border-color:#44ff44;box-shadow:0 0 30px #44ff44}"));
  client.print(F(".blue.on{background:#4444ff;border-color:#4444ff;box-shadow:0 0 30px #4444ff}"));
  client.print(F(".red.off{background:#ffcccc}.green.off{background:#ccffcc}.blue.off{background:#ccccff}"));
  client.print(F(".btn-group{display:flex;gap:8px;justify-content:center;margin-top:12px}"));
  client.print(F("button{padding:8px 16px;border:none;border-radius:5px;cursor:pointer;font-size:13px;font-weight:bold;transition:all 0.3s}"));
  client.print(F("button:disabled{opacity:0.5;cursor:not-allowed}"));
  client.print(F(".btn-on{background:#4CAF50;color:white}.btn-on:hover:not(:disabled){background:#45a049}"));
  client.print(F(".btn-off{background:#f44336;color:white}.btn-off:hover:not(:disabled){background:#da190b}"));
  client.print(F("table{width:100%;border-collapse:collapse;margin-top:12px;font-size:14px}"));
  client.print(F("th,td{padding:10px;text-align:left;border-bottom:1px solid #ddd}"));
  client.print(F("th{background:#f8f9fa;font-weight:600;color:#555}tr:hover{background:#f8f9fa}"));
  client.print(F(".badge{display:inline-block;padding:3px 10px;border-radius:12px;font-size:11px;font-weight:bold}"));
  client.print(F(".badge-admin{background:#667eea;color:white}.badge-user{background:#ffc107;color:#333}"));
  client.print(F("</style></head><body>"));
  
  // Header section
  client.print(F("<div class='header'><div class='header-content'><h1>🚀 Arduino GIGA LED Control</h1><div class='user-info'>"));
  client.print(F("<span class='badge badge-"));
  client.print(session.role == 2 ? F("admin'>👑 ADMIN") : F("user'>👤 USER"));
  client.print(F("</span><span>"));
  client.print(session.username);
  client.print(F("</span><a href='/logout' class='logout-btn'>Logout</a></div></div></div>"));
  
  // LED Controls
  client.print(F("<div class='container'><div class='card'><h2>💡 LED Status</h2><div class='led-grid'>"));
  
  // Red LED
  client.print(F("<div class='led-control'><div class='led-indicator red "));
  client.print(ledRed ? F("on") : F("off"));
  client.print(F("'></div><h3>🔴 Red LED</h3><p>Status: <strong>"));
  client.print(ledRed ? F("ON") : F("OFF"));
  client.print(F("</strong></p>"));
  if(session.role == 2) {
    client.print(F("<div class='btn-group'><button class='btn-on' onclick=\"setLED('red','on')\">Turn ON</button>"));
    client.print(F("<button class='btn-off' onclick=\"setLED('red','off')\">Turn OFF</button></div>"));
  }
  client.print(F("</div>"));
  
  // Green LED
  client.print(F("<div class='led-control'><div class='led-indicator green "));
  client.print(ledGreen ? F("on") : F("off"));
  client.print(F("'></div><h3>🟢 Green LED</h3><p>Status: <strong>"));
  client.print(ledGreen ? F("ON") : F("OFF"));
  client.print(F("</strong></p>"));
  if(session.role == 2) {
    client.print(F("<div class='btn-group'><button class='btn-on' onclick=\"setLED('green','on')\">Turn ON</button>"));
    client.print(F("<button class='btn-off' onclick=\"setLED('green','off')\">Turn OFF</button></div>"));
  }
  client.print(F("</div>"));
  
  // Blue LED
  client.print(F("<div class='led-control'><div class='led-indicator blue "));
  client.print(ledBlue ? F("on") : F("off"));
  client.print(F("'></div><h3>🔵 Blue LED</h3><p>Status: <strong>"));
  client.print(ledBlue ? F("ON") : F("OFF"));
  client.print(F("</strong></p>"));
  if(session.role == 2) {
    client.print(F("<div class='btn-group'><button class='btn-on' onclick=\"setLED('blue','on')\">Turn ON</button>"));
    client.print(F("<button class='btn-off' onclick=\"setLED('blue','off')\">Turn OFF</button></div>"));
  }
  client.print(F("</div></div></div>"));
  
  // History table
  client.print(F("<div class='card'><h2>📜 Activity Log (Last 10 Changes)</h2>"));
  client.print(F("<table><thead><tr><th>Time</th><th>User</th><th>Action</th></tr></thead><tbody>"));
  
  for(int i = historyCount - 1; i >= 0; i--) {
    int idx = (historyIndex - historyCount + i + HISTORY_SIZE) % HISTORY_SIZE;
    client.print(F("<tr><td>"));
    client.print(history[idx].timestamp);
    client.print(F("</td><td>"));
    client.print(history[idx].user);
    client.print(F("</td><td>"));
    client.print(history[idx].action);
    client.print(F("</td></tr>"));
  }
  
  client.print(F("</tbody></table></div></div>"));
  client.print(F("<script>function setLED(c,s){window.location.href='/led?color='+c+'&state='+s;}</script>"));
  client.print(F("</body></html>"));
}

#endif