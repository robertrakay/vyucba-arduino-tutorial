#include <WiFi.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>

// Include all header files
#include "config.h"
#include "authentication.h"
#include "led_control.h"
#include "history_log.h"
#include "websocket_handler.h"
#include "html_pages.h"
#include "http_server.h"

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("\n=== Arduino GIGA LED Control System ===");
  
  // Initialize LEDs
  initLEDs();
  
  // Test LEDs
  testLEDs();
  
  // Connect to WiFi
  Serial.print("Connecting to WiFi: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 20) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\n✓ WiFi Connected!");
    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());
    Serial.print("Subnet Mask: ");
    Serial.println(WiFi.subnetMask());
    Serial.print("Gateway: ");
    Serial.println(WiFi.gatewayIP());
  } else {
    Serial.println("\n✗ WiFi Connection FAILED!");
    Serial.println("Check SSID and password, then reset the board.");
    while(1) { delay(1000); }  // Halt
  }
  
  // Start servers
  initHTTPServer();
  initWebSocket();
  
  Serial.println("\n=== SYSTEM READY ===");
  Serial.print("Access the interface at: http://");
  Serial.println(WiFi.localIP());
  Serial.println("====================\n");
}

void loop() {
  handleHTTPRequests();
  webSocket.loop();
}