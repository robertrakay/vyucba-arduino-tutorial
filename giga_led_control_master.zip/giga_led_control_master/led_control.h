#ifndef LED_CONTROL_H
#define LED_CONTROL_H

#include <Arduino.h>
#include <ArduinoJson.h>
#include "config.h"
#include "history_log.h"
#include "authentication.h"

// LED states
bool ledRed = false;
bool ledGreen = false;
bool ledBlue = false;

// Forward declaration
void broadcastLEDState();

// Set LED state
void setLED(String color, bool state) {
  String action = "";
  
  if(color == "red") {
    ledRed = state;
    digitalWrite(LED_RED, !state);  // Active LOW
    action = state ? "Red ON" : "Red OFF";
  }
  else if(color == "green") {
    ledGreen = state;
    digitalWrite(LED_GREEN, !state);
    action = state ? "Green ON" : "Green OFF";
  }
  else if(color == "blue") {
    ledBlue = state;
    digitalWrite(LED_BLUE, !state);
    action = state ? "Blue ON" : "Blue OFF";
  }
  
  // Now add to history with proper string
  addToHistory(session.username, action);
  
  // Broadcast LED state to all connected clients
  broadcastLEDState();
}

// Get current LED states as JSON
String getLEDStateJSON() {
  StaticJsonDocument<200> doc;
  doc["red"] = ledRed;
  doc["green"] = ledGreen;
  doc["blue"] = ledBlue;
  
  String output;
  serializeJson(doc, output);
  return output;
}

// Initialize LED pins
void initLEDs() {
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_BLUE, OUTPUT);
  digitalWrite(LED_RED, HIGH);    // OFF
  digitalWrite(LED_GREEN, HIGH);  // OFF
  digitalWrite(LED_BLUE, HIGH);   // OFF
  
  Serial.println("LEDs initialized (all OFF)");
}

// Test LEDs at startup
void testLEDs() {
  Serial.println("\n=== Testing LEDs ===");
  
  Serial.println("Red ON");
  digitalWrite(LED_RED, LOW);   // ON
  delay(500);
  digitalWrite(LED_RED, HIGH);  // OFF
  
  Serial.println("Green ON");
  digitalWrite(LED_GREEN, LOW);
  delay(500);
  digitalWrite(LED_GREEN, HIGH);
  
  Serial.println("Blue ON");
  digitalWrite(LED_BLUE, LOW);
  delay(500);
  digitalWrite(LED_BLUE, HIGH);
  
  Serial.println("=== LED Test Complete ===\n");
}

#endif