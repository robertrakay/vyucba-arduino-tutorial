#ifndef CONFIG_H
#define CONFIG_H

// RGB LED Pin Definitions
#ifndef LED_RED
  #define LED_RED 86
#endif
#ifndef LED_GREEN
  #define LED_GREEN 87
#endif
#ifndef LED_BLUE
  #define LED_BLUE 88
#endif

// WiFi Configuration
const char* WIFI_SSID = "XXXXXXXX"; // USE YOUR WIFI
const char* WIFI_PASSWORD = "YYYYYYYYY";// oONT FORGET PASSWORD

// Server Ports
const int HTTP_PORT = 80;
const int WEBSOCKET_PORT = 81;

// History Log Size
const int HISTORY_SIZE = 10;

#endif